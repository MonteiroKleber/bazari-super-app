// Atualizando o index para incluir as novas páginas
// src/pages/dao/index.ts

export { DaoHome } from './DaoHome'
export { DaoProposals } from './DaoProposals'
export { DaoProposalDetail } from './DaoProposalDetail'
export { DaoCreateProposal } from './DaoCreateProposal'
export { DaoVotes } from './DaoVotes'
export { DaoTreasury } from './DaoTreasury'

