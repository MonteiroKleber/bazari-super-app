import React from "react";
import { Link } from "react-router-dom";

// Hub super simples e sem dependência de componentes globais,
// para não quebrar nada. Se quiser, depois troque por <Card /> e <Button /> do projeto.

const tiles = [
  { to: "/marketplace", title: "Marketplace", desc: "Compre e venda digitais e produtos." },
  { to: "/work",        title: "Work",        desc: "Projetos, propostas e escrow." },
  { to: "/wallet",      title: "Wallet",      desc: "Contas, tokens e NFTs." },
  { to: "/dao",         title: "DAO",         desc: "Governança e propostas." },
  { to: "/search",      title: "Busca",       desc: "Encontre usuários, lojas e itens." },
  { to: "/profile",     title: "Perfil",      desc: "Seus dados e preferências." },
];

export default function DashboardHome() {
  return (
    <div className="mx-auto w-full max-w-6xl p-4 md:p-6">
      <header className="mb-6 flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-sm text-muted-foreground">
            Ponto de partida para todos os módulos do ecossistema Bazari.
          </p>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {tiles.map((t) => (
          <Link
            key={t.to}
            to={t.to}
            className="group rounded-xl border bg-card p-5 shadow-sm transition hover:shadow-md"
          >
            <div className="mb-1 text-lg font-semibold">{t.title}</div>
            <p className="text-sm text-muted-foreground">{t.desc}</p>
            <div className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-yellow-600 group-hover:underline">
              Acessar <span aria-hidden>→</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
