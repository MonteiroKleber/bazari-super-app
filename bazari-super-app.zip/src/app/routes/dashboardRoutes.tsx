import React, { lazy } from "react";

const DashboardHome = lazy(() => import("../../pages/DashboardHome"));

const routes = [
  {
    path: "/dashboard",
    element: <DashboardHome />,
  },
];

export default routes;
