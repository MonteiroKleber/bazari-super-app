// src/features/social/components/index.ts

export { PostCard } from './PostCard'
export { NotificationItem } from './NotificationItem'