// src/features/dao/components/index.ts

export { ProposalCard } from './ProposalCard'
export { VoteBreakdown } from './VoteBreakdown'
export { TreasuryWidget } from './TreasuryWidget'