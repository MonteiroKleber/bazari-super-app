// src/features/marketplace/components/digital/index.ts
// Re-exports para componentes digitais

export { DigitalBadge } from './DigitalBadge'
export { RoyaltyChip } from './RoyaltyChip'
export { LicensePill } from './LicensePill'